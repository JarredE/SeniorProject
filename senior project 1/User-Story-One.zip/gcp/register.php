<?php
// Include config file
require_once "./scripts/mysql_connection.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
$first_name = "";
$last_name = "";
$phone = "";
$location = "";
$notif_pref = "";

 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["EMAIL"]))){
        $username_err = "Please enter an e-mail.";
    } else{
        // Prepare a select statement
        $sql = "SELECT FIRST_NAME FROM REFERRER WHERE EMAIL = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["EMAIL"]);
            $param_fname = trim($_POST["FIRST_NAME"]);
            $param_lname = trim($_POST["LAST_NAME"]);
            $param_phone = trim($_POST["PHONE"]);
            $param_location = trim($_POST["NOTIF_PREF"]);
            $param_notif = trim($_POST["LOCATION"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This e-mail is already registered with us.";
                } else{
                    $username = trim($_POST["EMAIL"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["EMAIL_PASS"]))){
        $password_err = "";     
    } elseif(strlen(trim($_POST["EMAIL_PASS"])) < 1){
        $password_err = "";
    } else{
        $password = trim($_POST["EMAIL_PASS"]);
    }
    
  
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err)){
        
        // Prepare an insert statement to store referrer info
        $sql = "INSERT INTO REFERRER (FIRST_NAME, LAST_NAME, EMAIL, EMAIL_PASS, PHONE, NOTIF_PREF, LOCATION) VALUES (?, ?, ?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssss", $param_fname, $param_lname, $param_username, $param_password, $param_phone, $param_notif, $param_location);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Create a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page after registration
                header("location: login.php");
                
            } else{
                echo "Oops! Something went wrong. Please try again.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Refer a Student DEMO - Register | UNF Digital</title>
		<link href="./css/main.css" rel="stylesheet"/>
		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script type="text/javascript" src="script.js"></script>
		
		
		
		
	</head>
	
	<header class="top-head"></header>	
<header class="header">
  <a href="#default" class="logo"><img src="images/untitled-design-52.png"/></a>
  <div class="header-right">
  </div>
</header>
	
	<body>
	
	<div class="wrapper">
		<div class="s-space"></div>
	<span class="text-sub">Welcome, Sponsor!</span>
	<h1 class="text-primary">Let's get you registered with us.</h1><br>
	<p class="text-primary">Note: Parents cannot submit referrals. Please see your child's school guidance counselor for assistance with our program.</p>
	<div class="c-box">
          	<form action="register.php" method="post">
          		<table>
          	<tr>
          	<td><input type="text" name="FIRST_NAME" id="FIRST_NAME" placeholder="First Name" required></td>
          	<td><input type="text" name="LAST_NAME" id="LAST_NAME" placeholder="Last Name" required></td>
          	</tr>
          	<tr>
          	<td colspan="2"><input type="text" name="EMAIL" id="EMAIL" placeholder="E-mail Address" required></td>
          	</tr>
          	<tr>
          	<td><input type="tel" name="PHONE" id="PHONE" placeholder="Phone Number" required></td>
          	<td><select name="NOTIF_PREF" id="NOTIF_PREF" required>
							<option value="0">How would you like to be notified?</option>
							<option value="1">Email</option>
							<option value="2">Phone</option>
							<option value="3">Either</option>
						</select></td>
          	</tr>
          	<tr>
          	<td colspan="2"><select name="LOCATION" id="LOCATION" required>
							<option value="0">Select Our Nearest Location</option>
							<option value="1">Duval County</option>
							<option value="2">Palm Beach County</option>
							</select></td>
          	</tr>
          		<tr><td colspan="2"><input type="submit" name="add" value="REGISTER"/></td></tr>
          		</table>
          		<input type="hidden" name="EMAIL_PASS" value="<?php echo $username?>">
          	</form>
          	<div class="back-btn"><a href="begin.php"><i class="fa fa-arrow-left"></i></a></div>
          </div>
		
		</div>
	</body>
</html>