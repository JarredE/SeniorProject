<?php
// Initialize the session
session_start();
 
// Check if the user has already logged in. If yes, then redirect to form.
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}
 
// Include config file
require_once "./scripts/mysql_connection.php";
 
// Define login variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username (e-mail) is empty
    if(empty(trim($_POST["EMAIL"]))){
        $username_err = "Please enter your e-mail.";
    } else{
        $username = trim($_POST["EMAIL"]);
    }
    
    // Check if password (e-mail) is empty
    if(empty(trim($_POST["EMAIL_PASS"]))){
        $password_err = "";
    } else{
        $password = trim($_POST["EMAIL_PASS"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT USER_ID, EMAIL, EMAIL_PASS FROM REFERRER WHERE EMAIL = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["USER_ID"] = $id;
                            $_SESSION["EMAIL"] = $username;                           
                            
                            // Redirect user to referrals home
                            header("location: index.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid e-mail";
                        }
                    }
                } else{
                    // E-mail doesn't exist, display a generic error message
                    $login_err = "We don't have that e-mail in our system, please select new user.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Refer a Student DEMO - Login | UNF Digital</title>
		<link href="./css/main.css" rel="stylesheet"/>
		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script type="text/javascript" src="script.js"></script>
		
		
		
		
	</head>
	
	<header class="top-head"></header>	
<header class="header">
  <a href="#default" class="logo"><img src="images/untitled-design-52.png"/></a>
  <div class="header-right">
  </div>
</header>
	
	<body>
	<div class="wrapper">
	<div class="l-space"></div>
	<span class="text-sub">Welcome back!</span>
	<h1 class="text-primary">Enter the email you registered with us.</h1><br>
	<div class="c-box">
          	<form action="login.php" method="post">
          		<table>
          		<tr><input type="text" name="EMAIL" placeholder="E-mail Address" required></tr>
          		<br><br>
          		<tr><input type="submit" value="ENTER"/></tr>
          		</table>
          		<input type="hidden" name="EMAIL_PASS" value="<?php echo $username?>">
          	</form>
		<div class="back-btn"><a href="begin.php"><i class="fa fa-arrow-left"></i></a></div>
		</div>
		</div>
	</body>
</html>