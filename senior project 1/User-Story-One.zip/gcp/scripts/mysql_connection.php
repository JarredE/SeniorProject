<?php
$link = mysqli_connect('localhost','unfdigital','Fall2021','iteration1');

if (!$link) {
	echo 'connection error: ' . mysqli_connect_error();
}

//!TAWQ?W^>Yiq]9&*
?>