<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect to form start page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: begin.php");
    exit;
}
?>

<?php
//get list of books
require_once "./scripts/mysql_connection.php";

$id = $_SESSION["USER_ID"];
$dynamicList = "";
$sql = mysqli_query($link, "SELECT USER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE, NOTIF_PREF, LOCATION FROM REFERRER WHERE USER_ID = '$id' ");
$productCount = mysqli_num_rows($sql); // count the output amount
if ($productCount > 0) {
	while($row = mysqli_fetch_array($sql)){ 
             $userid = $row["USER_ID"];
			 $fname = $row["FIRST_NAME"];
			 $lname = $row["LAST_NAME"];
			 $email = $row["EMAIL"];
			 $phone = $row["PHONE"];
			 $notif = $row["NOTIF_PREF"];
			 $location = $row["LOCATION"];
			 
			 
			 
			 $dynamicList .= '<table>
			 <th>First Name</th>
			 <th>Last Name</th>
			 <th>Email</th>
			 <th>Phone</th>
			 <th>Nearest GCP Location</th>
          		<tr>
          			<td>' .$fname. '</td>
          			<td>' .$lname. '</td>
          			<td>' .$email. '</td>
          			<td>' .$phone. '</td>
          			<td>' .$location. '</td>
          		</tr>
          	</table>';
    }
    
          	
          	
} else {
	$dynamicList = "We have no INFO on you in our system yet";
}

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Refer a Student - Home | UNF Digital</title>
		<link href="./css/main.css" rel="stylesheet"/>
		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script type="text/javascript" src="script.js"></script>
		
		
		
	</head>
	<body>
	<div class="wrapper">
		<h3><?php echo "Welcome, "; echo $_SESSION["EMAIL"];?></h3>
	
		 <div class="l-space"></div>
        
          	<?php echo $dynamicList ?>
          	
         
          
     <a href="logout.php"><i class="fas fa-sign-out-alt"></i>LOGOUT</a>
   
		 
		</div>
		
	</body>
</html>