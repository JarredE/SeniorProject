<?php
// Initialize the session
session_start();
 
// Include config file
require_once "./scripts/mysql_connection.php";

?>

<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<title>Refer a Student DEMO - Begin | UNF Digital</title>
		<link href="./css/main.css" rel="stylesheet"/>
		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
		<script type="text/javascript" src="script.js"></script>
		
		
		
		
	</head>
<header class="top-head"></header>	
<header class="header">
  <a href="#default" class="logo"><img src="images/untitled-design-52.png"/></a>
  <div class="header-right">
  </div>
</header>

	<body>
	<div class="wrapper">
	<div class="l-space"></div>
	<div class="intro">
	<h1>Refer a Student in Need</h1>
	<p><span>We’re here to support you and the&nbsp;students you serve by providing clothing, hygiene, and other basic essentials to low income and homeless youth in need.</span></p>
	
	<p><em>*Currently providing emergency, basic needs assistance to youth and school communities in Jacksonville and Palm Beach Florida</em></p>
	<p>Please note that this referral is to be completed only by school/district staff or staff from other Social Service Agencies. This includes teachers, case managers, counselors, social workers, etc. The GCP is the bridge for connecting school communities with clothing, hygiene products and other basic essentials to ensure their low-income and homeless youth have access to these items throughout the school year.</p>
	<p>If you are a parent seeking help for your child, please reach out to the guidance counselor at your child’s school.</p>
	</div>
	<div id="boxes">
	<table><tr><td>
        <h2>First Referral?</h2><h3>Welcome!</h3></td>
        <td><h2>Returning users</h2><h3>Welcome back!</h3>
        </td></tr>
          		<tr><td><a href="register.php">Start here</a></td><td>
          		
          		<a href="login.php">Login</a></td>
          		</tr>
		</table>
		</div>
		</div>
	</body>
</html>